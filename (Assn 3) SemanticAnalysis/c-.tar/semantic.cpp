#include "semantic.h"
#include "symbolTable.h"
#include "tree.h"
#include "c-.tab.h"
#include <string.h>
#include <string>
int numWarnings;
extern int numErrors;
extern bool semanticDebugging;
bool mainDefined = false;
bool ignoreNextCompound = false;//used to not create duplicate compound statements for functions
bool prevOperation = true;
struct TreeNode* prevT = NULL;

void semanticAnalysis(struct TreeNode *syntaxTree, SymbolTable *symbolTable)
{
    if (mainDefined == false) {
        printf("ERROR(LINKER): A function named 'main()' must be defined.\n");
        numErrors++;
    }
    //!Assignment3Only
    bool typingOn = true; //used to turn on/off typing (used in Range statements) so my output matches correctly
    treeTraverse(syntaxTree, symbolTable, typingOn);
    return;
}
void treeTraverse(struct TreeNode *t, SymbolTable *symbolTable, bool typingOn)
{
    std::string s; //for conver ting c strings to std strings
    struct TreeNode* temp = NULL;
    struct TreeNode* temp2 = NULL;
    struct operatorTypes* opTypes = NULL;
    ExpType lhsType;
    ExpType rhsType;
    bool rhsIsArray = false; //true if rhs is unindexed array
    bool lhsIsArray = false; //true if lhs is unindexed array
    bool isUnary = false;
    bool isBinary = false;
    bool turnWarningsOn = false; //An error may cause warnings to be turned off for the rest of that statement. This is used to turn them back on.
    bool rhsFunctionAsVariable = false;
    bool lhsFunctionAsVariable = false;
    char *scopeName = NULL;
    bool exitScope = false;
    if (t != NULL) {

        switch (t->nodekind) {
            case DeclK:
            {
                if (t->kind.DeclK == ParmK || t->kind.DeclK == VarDeclK) {
                    if ((symbolTable->insert(t->attr.name, (TreeNode*) t)) == false) {
                        printf("ERROR(%d): Symbol '%s' is already declared at line %d.\n", t->lineno, t->attr.name, ((TreeNode*)symbolTable->lookup(s.assign(t->attr.name)))->lineno);
                        numErrors++;
                    }
                    if (t->child[0] != NULL) {
                        t->isInitialized = true;
                    }
                }
                else if (t->kind.DeclK == FuncDeclK) {
                    if ((symbolTable->insert(t->attr.name, (TreeNode*) t)) == false) {
                        printf("ERROR(%d): Symbol '%s' is already declared at line %d.\n", t->lineno, t->attr.name, ((TreeNode*)symbolTable->lookup(s.assign(t->attr.name)))->lineno);
                        numErrors++;
                    }
                    
                    //if its a function declaration with a single statement (not compound) following, we still need a new scope
                    if (t->kind.DeclK == FuncDeclK) {
                        if (t->child[1] != NULL) {

                            if(t->child[1]->kind.StmtK != CompoundK) {
                                //statement that follows will be a single statement
                                //we have to create the scope now to allow parameters to be added to the function's scope
                                scopeName = (char*)malloc(sizeof(char) * (strlen(t->attr.name) + strlen("FuncScope") + 1));
                                strcat(scopeName, t->attr.name);
                                strcat(scopeName, "FuncScope");
                                symbolTable->enter((std::string) scopeName);
                            }
                            else {
                                //This is a function's main compound statement
                                //we have to create the scope now to allow parameters to be added to the function's scope
                                scopeName = (char*)malloc(sizeof(char) * (strlen(t->attr.name) + strlen("FuncScope(Compound)") + 1));
                                strcat(scopeName, t->attr.name);
                                strcat(scopeName, "FuncScope(Compound)");
                                symbolTable->enter((std::string) scopeName);
                                //Need to know the prev definition was a function so we dont create two compount stmt scopes
                                ignoreNextCompound = true;
                            }
                            exitScope = true;
                        }
                    }
                }
                break;
            }
            case StmtK:
            {
                if (t->kind.StmtK == CompoundK) {

                    if (ignoreNextCompound == true) {
                        //Dont need to do anything because a compound statement scope was created before this point
                        ignoreNextCompound = false;
                    }
                    else {
                        scopeName = (char*)malloc(sizeof(char) * strlen("CompoundScope") + 26);
                        sprintf(scopeName, "%d", t->lineno);
                        strcat(scopeName, "CompoundScope");
                        symbolTable->enter((std::string) scopeName);
                        exitScope = true;
                    }
                    
                }
                else if (t->kind.StmtK == ForK) {
                    if (t->child[2] != NULL) {
                        if (t->child[2]->nodekind == StmtK) {
                            if(t->child[2]->kind.StmtK != CompoundK) {
                                scopeName = (char*)malloc(sizeof(char) * strlen("ForScope") + 26);
                                sprintf(scopeName, "%d", t->lineno);
                                strcat(scopeName, "ForScope");
                                symbolTable->enter((std::string) scopeName);
                                exitScope = true;
                            }
                            else {
                                scopeName = (char*)malloc(sizeof(char) * strlen("ForScope(Compound)") + 26);
                                sprintf(scopeName, "%d", t->lineno);
                                strcat(scopeName, "ForScope(Compound)");
                                symbolTable->enter((std::string) scopeName);
                                ignoreNextCompound = true;
                                exitScope = true;
                            }
                        }
                        else {
                                scopeName = (char*)malloc(sizeof(char) * strlen("ForScope") + 26);
                                sprintf(scopeName, "%d", t->lineno);
                                strcat(scopeName, "ForScope");
                                symbolTable->enter((std::string) scopeName);
                                exitScope = true;
                        }
                    }
                }
                else if (t->kind.StmtK == ReturnK) {
                    if (t->child[0] != NULL) {
                        if (t->child[0]->kind.ExpK == IdK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->attr.name))) != NULL) {
                                if(temp->isArray) {
                                    printf("ERROR(%d): Cannot return an array.\n", t->lineno);
                                    numErrors++;
                                }
                            }
                        }
                    }
                } else if (t->kind.StmtK == RangeK) {
                    //!Assignment3Only
                    //turn make all types in range statement undefined
                    typingOn = false;
                    //!Assignment3Only
                    //turn off warnings for variables in Range node (for loops assignment 3)
                   if (t->child[0] != NULL) {
                       if(t->child[0]->kind.ExpK == IdK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->attr.name))) != NULL) {
                                temp->printInitializedWarning = false;
                                turnWarningsOn = true;
                            }   
                        }
                        else if (t->child[0]->kind.ExpK == IdArrK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->child[0]->attr.name))) != NULL) {
                                temp->printInitializedWarning = false;
                                turnWarningsOn = true;
                            }   
                        }
                    }
                    if (t->child[1] != NULL) {
                       if(t->child[1]->kind.ExpK == IdK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->attr.name))) != NULL) {
                                temp->printInitializedWarning = false;
                                turnWarningsOn = true;
                            }   
                        }
                        else if (t->child[1]->kind.ExpK == IdArrK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->child[0]->attr.name))) != NULL) {
                                temp->printInitializedWarning = false;
                                turnWarningsOn = true;
                            }   
                        }
                    }
                    if (t->child[2] != NULL) {
                       if(t->child[2]->kind.ExpK == IdK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[2]->attr.name))) != NULL) {
                                temp->printInitializedWarning = false;
                                turnWarningsOn = true;
                            }   
                        }
                        else if (t->child[2]->kind.ExpK == IdArrK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[2]->child[0]->attr.name))) != NULL) {
                                temp->printInitializedWarning = false;
                                turnWarningsOn = true;
                            }   
                        }
                    }
                }

                break;
            }
            case ExpK:
            {
                if (t->kind.ExpK == CallK) {
                    if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->attr.name))) != NULL) {
                        temp->isUsed = true;
                        //!Assignment3Only!
                        //Make variable types in Range stmt type Undefined
                        if (typingOn == false) {
                            t->expType = Undefined;
                        }
                        else {
                            t->expType = temp->expType;
                        }
                        if (temp->kind.DeclK == VarDeclK || temp->kind.DeclK == ParmK) {
                            printf("ERROR(%d): '%s' is a simple variable and cannot be called.\n", t->lineno, t->attr.name);
                            numErrors++;
                        }
                    }
                    else {
                        printf("ERROR(%d): Symbol '%s' is not declared.\n", t->lineno, t->attr.name);
                        numErrors++;
                    }
                }
                if (t->kind.ExpK == IdK) {
                    if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->attr.name))) != NULL) {
                        if (typingOn == true) {
                            temp->isUsed = true;
                        }
                        //!Assignment3Only!
                        //Make variable types in Range stmt type Undefined
                        if (typingOn == false) {
                            t->expType = Undefined;
                        }
                        else {
                            t->expType = temp->expType;
                        }
                        if (temp->isInitialized == false) {
                            if (temp->printInitializedWarning == true) {
                                if (temp->kind.DeclK != ParmK && temp->isScoped == true && temp->isStatic == false && temp->kind.DeclK != FuncDeclK) {
                                    printf("WARNING(%d): Variable '%s' may be uninitialized when used here.\n", t->lineno, temp->attr.name);
                                    temp->isInitialized = true;
                                    temp->printInitializedWarning = false;
                                    numWarnings++;
                                }
                            }
                        }
                        if (temp->kind.DeclK == FuncDeclK) {
                            printf("ERROR(%d): Cannot use function '%s' as a variable.\n", t->lineno, temp->attr.name);
                            numErrors++;
                        }
                    }
                    else {
                        if (typingOn == true) { //!Assignment3Only
                            printf("ERROR(%d): Symbol '%s' is not declared.\n", t->lineno, t->attr.name);
                            numErrors++;
                        }
                    }
                }
                else if (t->kind.ExpK== IdArrK) {
                    lhsType = getChildType(t->child[0], symbolTable);
                    rhsType = getChildType(t->child[1], symbolTable);
                    if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->attr.name))) != NULL) {
                        //!Assignment3Only!
                        //Make variable types in Range stmt type Undefined
                        if (typingOn == false) {
                            t->expType = Undefined;
                        }
                        else {
                            t->expType = temp->expType;
                        }
                        if (temp->isArray == false) {
                            printf("ERROR(%d): Cannot index nonarray '%s'.\n", t->lineno, temp->attr.name);
                            numErrors++;
                        }
                    }
                    else {
                        printf("ERROR(%d): Cannot index nonarray '%s'.\n", t->lineno, t->child[0]->attr.name);
                        numErrors++;
                    }
                    if (rhsType != Integer && rhsType != Undefined) {
                        printf("ERROR(%d): Array '%s' should be indexed by type int but got type %s.\n", t->lineno, t->child[0]->attr.name, getTypeName(rhsType));
                        numErrors++;
                        //Turn off warnings for the rest of the items involved in this error
                        turnWarningsOn = true;
                        temp2 = t;
                        while (temp2 != NULL) {
                            if (temp2->kind.ExpK == IdArrK) {
                                if ((temp = (TreeNode*)symbolTable->lookup(s.assign(temp2->child[0]->attr.name))) != NULL) {
                                    temp->printInitializedWarning = false;
                                }
                            }
                            else if (temp2->kind.ExpK == IdK) {
                                if ((temp = (TreeNode*)symbolTable->lookup(s.assign(temp2->attr.name))) != NULL) {
                                    temp->printInitializedWarning = false;
                                }
                            }
                            temp2 = temp2->child[1];
                        }
                    }
                    if (t->child[1]->kind.ExpK == IdK) {
                       
                        if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->attr.name))) != NULL) {
                            //!Assignment3Only
                            temp->printInitializedWarning = false;
                            turnWarningsOn = true;
                            if (temp->isArray == true) {
                                printf("ERROR(%d): Array index is the unindexed array '%s'.\n", t->lineno, temp->attr.name);
                                numErrors++;
                            }
                        }
                    }
                }
                else if (t->kind.ExpK == AssignK || t->kind.ExpK == OpK) {
                    prevOperation = true;
                    //get operand and return type information for this operator
                    opTypes = getOperatorTypes(t->attr.op);
                    if (opTypes->isBinary == true && t->child[0] != NULL && t->child[1] != NULL) {
                        isBinary = true;
                        if (t->child[1]->nodekind == ExpK) {
                            if (t->child[1]->kind.ExpK == IdK) {
                                //This operator must be a binary operator.
                                //check if rhs is an unindexed array
                                //set variable as used
                                if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->attr.name))) != NULL) {
                                    if(typingOn == true) {
                                        temp->isUsed = true;
                                    }
                                    if (temp->isArray == true) {
                                        rhsIsArray = true;
                                    }
                                    //check if rhs is function used as variable
                                    if (temp->kind.DeclK == FuncDeclK) {
                                        rhsFunctionAsVariable = true;
                                    }
                                }
                            }
                            else if (t->child[1]->kind.ExpK == IdArrK) {
                                //set variable as used
                                if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->child[0]->attr.name))) != NULL) {
                                    if(typingOn == true) {
                                        temp->isUsed = true;
                                    }
                                }
                            }
                            else if (t->child[1]->kind.ExpK == ConstantK) {
                                if (t->child[1]->isArray == true) {
                                    rhsIsArray = true;
                                }
                            }
                        }
                        if (t->child[0]->nodekind == ExpK) {
                            if (t->child[0]->kind.ExpK == IdK) {
                                //check if lhs is an unindexed array 
                                //set variable as initialized if this is an assignment, but first check if lhs variable is the same as rhs variable. If it is, check if rhs is initialized and set lhsrhsSameAndUninitiated flag accordingly
                                if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->attr.name))) != NULL) {
                                    if (temp->kind.DeclK == FuncDeclK) {
                                        lhsFunctionAsVariable = true;
                                    }
                                    if (t->kind.ExpK == OpK) {
                                        if(typingOn == true) {
                                            temp->isUsed = true;
                                        }
                                    } else if (t->kind.ExpK == AssignK) {
                                        //if  rhs is an identifier
                                        if (t->child[1]->kind.ExpK == IdK) {
                                            if (strcmp(temp->attr.name, t->child[1]->attr.name) == 0) {
                                                if ((temp2 = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->attr.name))) != NULL) {
                                                    if (temp2->kind.DeclK == FuncDeclK) {
                                                        rhsFunctionAsVariable = true;
                                                    }
                                                    if (temp2->isInitialized == false) {
                                                        temp->isInitialized = false;
                                                    }
                                                }                                              
                                            }
                                            else {
                                                temp->isInitialized = true;
                                            }
                                        }
                                        //if rhs is array 
                                        else if (t->child[1]->kind.ExpK == IdArrK)  {
                                            if ((temp2 = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->child[0]->attr.name))) != NULL) { 
                                                if (temp2->kind.DeclK == FuncDeclK) {
                                                    rhsFunctionAsVariable = true;
                                                }
                                                if (strcmp(temp->attr.name, t->child[1]->child[0]->attr.name) == 0) {
                                                    if (temp2->isInitialized == false) {
                                                        temp->isInitialized = false;
                                                    }
                                                }
                                                else {
                                                    temp->isInitialized = true;
                                                }                                          
                                            }
                                            else {
                                                temp->isInitialized = true;
                                            }
                                        }
                                        else {
                                            temp->isInitialized = true;
                                        }
                                    }
                                    if (temp->isArray == true) {
                                        lhsIsArray = true;
                                    }
                                }
                            }
                            //if lhs is an array
                            else if (t->child[0]->kind.ExpK == IdArrK) {
                                if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->child[0]->attr.name))) != NULL) {
                                    if(temp->kind.DeclK == FuncDeclK) {
                                        lhsFunctionAsVariable = true;
                                    }
                                    if (t->kind.ExpK == OpK) {
                                        if(typingOn == true) {
                                            temp->isUsed = true;
                                        }
                                    } else if (t->kind.ExpK == AssignK) {
                                        //if rhs is an indexed array
                                        if (t->child[1]->kind.ExpK == IdArrK) {
                                            if (strcmp(temp->attr.name, t->child[1]->child[0]->attr.name) == 0) {
                                                if ((temp2 = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->child[0]->attr.name))) != NULL) {
                                                    if (temp2->isInitialized == false) {
                                                        temp->isInitialized = false;
                                                    }
                                                }                                              
                                            }
                                            else {
                                                temp->isInitialized = true;
                                            }
                                        }
                                        else if (t->child[1]->kind.ExpK == IdK) {
                                            if (strcmp(temp->attr.name, t->child[1]->attr.name) == 0) {
                                                if ((temp2 = (TreeNode*)symbolTable->lookup(s.assign(t->child[1]->attr.name))) != NULL) {
                                                    if (temp2->isInitialized == false) {
                                                        temp->isInitialized = false;
                                                    }
                                                }                                              
                                            }
                                            temp->isInitialized = true;
                                        }
                                        else {
                                            temp->isInitialized = true;
                                        }
                                    }
                                }
                            }
                            else if (t->child[0]->kind.ExpK == ConstantK) {
                                if (t->child[0]->isArray == true) {
                                    lhsIsArray = true;
                                }
                            }
                        }
                        lhsType = getChildType(t->child[0], symbolTable);
                        rhsType = getChildType(t->child[1], symbolTable);
                        //Set this operator's return type
                        if (opTypes->returnType == Undefined) {
                            //t->expType = lhsType;
                            //!Assignment3Only!
                            //Make variable types in Range stmt type Undefined
                            if (typingOn == false) {
                                t->expType = Undefined;
                            }
                            else {
                                t->expType = lhsType;
                            }
                            }
                        else {
                            //t->expType = opTypes->returnType;
                            //!Assignment3Only!
                            //Make variable types in Range stmt type Undefined
                            if (typingOn == false) {
                                t->expType = Undefined;
                            }
                            else {
                                t->expType = opTypes->returnType;
                            }
                        }
                        //begin error checking for binary operator
                        if (lhsFunctionAsVariable == true) {
                            //printf("ERROR(%d): Cannot use function '%s' as a variable.\n", t->lineno, t->child[0]->attr.name);
                            //numErrors++;
                        }
                        else if (rhsFunctionAsVariable == true) {
                            //printf("ERROR(%d): Cannot use function '%s' as a variable.\n", t->lineno, t->child[1]->attr.name);
                            //numErrors++; 
                        }
                        else {
                            if (opTypes->workWithArray == false && (rhsIsArray || lhsIsArray)) {
                                //operator does not work with array
                                printf("ERROR(%d): The operation '%s' does not work with arrays.\n", t->lineno, t->OpStr);
                                numErrors++;
                            }
                            else if (lhsIsArray == true && rhsIsArray == false) {
                                printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", t->lineno, t->OpStr, "", " not");
                                numErrors++;
                            }
                            else if (lhsIsArray == false && rhsIsArray == true) {
                                printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n", t->lineno, t->OpStr, " not", "");
                                numErrors++;
                            }
                            if (opTypes->oper1Type != Undefined && opTypes->oper2Type != Undefined) {
                                //operator must be AND, OR, :>:, or :<: since the operand types are not known and not of type "Undefined"
                                if (opTypes->oper1Type != lhsType && lhsType != Undefined) {
                                    printf("ERROR(%d): '%s' requires operands of type %s but lhs is of type %s.\n", t->lineno, t->OpStr, getTypeName(opTypes->oper1Type), getTypeName(lhsType));
                                    numErrors++;
                                }
                                if (opTypes->oper2Type != rhsType && rhsType != Undefined) {
                                    printf("ERROR(%d): '%s' requires operands of type %s but rhs is of type %s.\n", t->lineno, t->OpStr, getTypeName(opTypes->oper1Type), getTypeName(rhsType));
                                    numErrors++;
                                }
                            }
                            else {
                                //operator must be of type <, >,  +=, -=, *=, /= and the types on lhs and rhs must be equal
                                if (rhsType != lhsType && (rhsType != Undefined && lhsType != Undefined)) {
                                    printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n", t->lineno, t->OpStr, getTypeName(lhsType), getTypeName(rhsType));
                                    numErrors++;
                                }
                            }
                        }

                    } else {
                        lhsType = getChildType(t->child[0], symbolTable);
                        isUnary = true;
                        //This operator must be a unary operator
                        //Check if lhs is an array and set as used
                        if (t->child[0] != NULL) {
                            if (t->child[0]->nodekind == ExpK) {
                                if (t->child[0]->kind.ExpK == IdK) {
                                    //check if lhs is an unindexed array
                                    //set variable as used
                                    if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->attr.name))) != NULL) {
                                        if (temp->kind.DeclK == FuncDeclK) {
                                            lhsFunctionAsVariable = true;
                                        }
                                        if(typingOn == true) {
                                            temp->isUsed = true;
                                        }
                                        if (temp->isArray == true) {
                                            lhsIsArray = true;
                                        }
                                    }
                                } else if (t->child[0]->kind.ExpK == IdArrK) {
                                    if ((temp = (TreeNode*)symbolTable->lookup(s.assign(t->child[0]->child[0]->attr.name))) != NULL) {
                                    if(typingOn == true) {
                                        temp->isUsed = true;
                                    }
                                    }

                                } else if (t->child[0]->kind.ExpK == ConstantK) {
                                    if (t->child[0]->isArray == true) {
                                        lhsIsArray = true;
                                    }
                                }
                            }  
                        }
                        //set this operators return type
                        //t->expType = opTypes->returnType;
                        //!Assignment3Only!
                        //Make variable types in Range stmt type Undefined
                        if (typingOn == false) {
                            t->expType = Undefined;
                        }
                        else {
                            t->expType = opTypes->returnType;
                        }
                        //begin error checking for unary operator
                        if (lhsFunctionAsVariable == true) {
                                //printf("ERROR(%d): Cannot use function '%s' as a variable.\n", t->lineno, t->child[0]->attr.name);
                                //numErrors++;
                        }
                        else if (opTypes->workWithArray == false){
                            //operator does not work with array
                            if (lhsIsArray == true) {
                                printf("ERROR(%d): The operation '%s' does not work with arrays.\n", t->lineno, t->OpStr);
                                numErrors++;
                            }
                        }
                        else if(t->attr.op == SIZEOF) {
                            if (lhsIsArray != true &&lhsType != Undefined){
                                printf("ERROR(%d): The operation '%s' only works with arrays.\n", t->lineno, t->OpStr);
                                numErrors++;
                            }

                        }
                        if(opTypes->oper1Type != lhsType && lhsType != Undefined && opTypes->oper1Type != Undefined) {
                            printf("ERROR(%d): Unary '%s' requires an operand of type %s but was given type %s.\n", t->lineno, t->OpStr, getTypeName(opTypes->oper1Type), getTypeName(lhsType));
                            numErrors++;
                        }
                    }
                
                }
                break;
            }
            default: 
            {
                printf("ERROR\n");
            
            }
        }
        
        treeTraverse(t->child[0], symbolTable, typingOn);
        treeTraverse(t->child[1], symbolTable, typingOn);
        treeTraverse(t->child[2], symbolTable, typingOn);

        //turn warnings back on
        if (isBinary == true && turnWarningsOn == true) {
            temp2 = t;
                if (temp2->nodekind == ExpK) {
                    while (temp2 != NULL) {
                        if (temp2->kind.ExpK == IdArrK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(temp2->child[0]->attr.name))) != NULL) {
                                temp->printInitializedWarning = true;
                                temp2 = temp2->child[1];
                            }
                        }
                        else if (temp2->kind.ExpK == IdK) {
                            if ((temp = (TreeNode*)symbolTable->lookup(s.assign(temp2->attr.name))) != NULL) {
                                temp->printInitializedWarning = true;
                                temp2 = temp2->child[1];
                            }
                        }
                    }
                }
            turnWarningsOn = false;
        }
        if (exitScope == true)  {
            symbolTable->applyToAll(checkIfUsed);
            symbolTable->leave();
        }
        treeTraverse(t->sibling, symbolTable, typingOn);
    }
}
void checkIfUsed(std::string s, void* t) {
    TreeNode* tNode = (TreeNode*) t;
    if (tNode->kind.DeclK == VarDeclK || tNode->kind.DeclK == ParmK) {
        if (tNode->isUsed == false) {
            printf("WARNING(%d): The variable '%s' seems not to be used.\n", tNode->lineno, tNode->attr.name);
            tNode->isUsed = true;
            numWarnings++;
        }
    }

}
//Gets the type of a child node. Call this function by passing the child as a parameter
ExpType getChildType(TreeNode *t, SymbolTable *symTable)
{
    operatorTypes* opType = NULL;
    TreeNode* temp = t;
    std::string s;
    if (t->kind.ExpK == OpK || t->kind.ExpK == AssignK) {
        if (t->attr.op == int('=')) {
            if (t->child[0] != NULL) {
                return getChildType(t->child[0], symTable);
            }
        }
        else {
            opType = getOperatorTypes(t->attr.op);
            return opType->returnType;
        }
    }
    else if (t->kind.ExpK == ConstantK) {
        return (t->expType);
    }
    else if (t->kind.ExpK == IdK) {
        if ((temp = (TreeNode*)symTable->lookup(s.assign(t->attr.name))) != NULL) {
            return (temp->expType);
        }
        else {
            return Undefined;
        }
    }
    else if (t->kind.ExpK == IdArrK) {
        while (temp->kind.ExpK == IdArrK) {
            temp = temp->child[0];
        }
        if ((temp = (TreeNode*)symTable->lookup(s.assign(temp->attr.name))) != NULL) {
            return (temp->expType);
        }
        else {
            return Undefined; 
        }
    }
    else if (t->kind.ExpK == CallK) {
        if ((temp = (TreeNode*)symTable->lookup(s.assign(temp->attr.name))) != NULL) {
            return (temp->expType);
        }
    }
    return Undefined;
}
//Creates a struct that holds operand types and return types for a given operator. This struct may not necessarily be complete, depending on the operator
//Any values set to an undefined type will need to be changed later. Returns struct *.
struct operatorTypes* getOperatorTypes(OpKind op) 
{
    operatorTypes* opTypes = new operatorTypes;
    if (op == ADDASS || op == SUBASS || op == MULASS || op == ADDASS || op == DIVASS || op == MAX || op == MIN || op == int('*') || op == int('/') || op == int('+') || op == int('-') || op == int('%')) {
        opTypes->oper1Type = Integer;
        opTypes->oper2Type = Integer;
        opTypes->returnType = Integer;
        opTypes->arrayOnly = false;
        opTypes->workWithArray = false;
        opTypes->lhsRhsSame = true;
        opTypes->isBinary = true;
    }
    else if (op == int ('=')) {
        opTypes->oper1Type = Undefined;
        opTypes->oper2Type = Undefined;
        opTypes->returnType = Undefined;
        opTypes->arrayOnly = false;
        opTypes->workWithArray = true;
        opTypes->lhsRhsSame = true;
        opTypes->isBinary = true;
    }
    else if (op == EQ || op == NEQ || op == LEQ || op == GEQ || op == int('<') || op == int('>')) {
        opTypes->oper1Type = Undefined;
        opTypes->oper2Type = Undefined;
        opTypes->returnType = Boolean;
        opTypes->arrayOnly = false;
        opTypes->workWithArray = true;
        opTypes->lhsRhsSame = true;
        opTypes->isBinary = true;
    }
    else if (op == DEC || op == INC || op == NOT || op == SIZEOF || op == CHSIGN || op == int('?')) {
        opTypes->oper2Type = Undefined;
        opTypes->oper1Type = Undefined;
        opTypes->arrayOnly = false;
        opTypes->workWithArray = false;
        if(op != NOT) {
            opTypes->returnType = Integer;
            if (op == SIZEOF) {
                opTypes->oper1Type = Undefined;
                opTypes->workWithArray = true;
                opTypes->arrayOnly = true;
            }
            else {
                opTypes->oper1Type = Integer;
            }
        }
        else {
            //operator is NOT
            opTypes->returnType = Boolean;
            opTypes->oper1Type = Boolean;
        }
        //This is how we can distinguish unary operators from binary. All binary ops require both sides to be the same
        opTypes->lhsRhsSame = false;
        opTypes->isBinary = false;
    }
    else if (op == AND || op == OR) {
        opTypes->oper1Type = Boolean;
        opTypes->oper2Type = Boolean;
        opTypes->returnType = Boolean;
        opTypes->arrayOnly = false;
        opTypes->workWithArray = false;
        opTypes->lhsRhsSame = true;
        opTypes->isBinary = true;
    }
    else {
        printf("There was a problem in getOperatorTypes()\n");
    }
    return opTypes;
}